package controler;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Product;
import model.Services;

import java.io.IOException;
import java.util.List;

/**
 * Servlet implementation class FindProduct
 */
public class FindProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FindProduct() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String valueSearch = request.getParameter("searchValue");
		Services sv = (Services) request.getSession().getAttribute("service");
		if(sv == null) {
			sv = new Services();
			request.getSession().setAttribute("service", sv);
		}
		List<Product> listProduct = sv.searchProduct(valueSearch);
		
		request.setAttribute("valueSearch", valueSearch);
		request.setAttribute("listProduct", listProduct);
		getServletContext().getRequestDispatcher("/LookUp.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
